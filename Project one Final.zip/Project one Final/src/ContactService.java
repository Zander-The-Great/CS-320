import java.util.HashMap;

public class ContactService {
	int currentID = 0;
	HashMap<String, Contact> contacts = new HashMap<String, Contact>(); //hash map to hold contacts
	
	//Adds a contact @param first,last,phoneNumber, theAddress
	public void addContact(String first, 
			String last,
			String phoneNumber,
			String theAddress) {
		++currentID;
		String newID = Integer.toString(currentID);
		
		try {
			Contact newContact = new Contact(newID, first, last, phoneNumber, theAddress);
			contacts.put(newContact.getID(), newContact);
		} catch(IllegalArgumentException i) {
			i.printStackTrace();
		}
	}
	
	//Deletes a contact by ID
	public void deleteContact(String ID) {
		if (contacts.containsKey(ID)) {
			contacts.remove(ID);
		}
	}
	
	//Updates first name
	public void updateFirstName(String ID, String newName) {
		if (contacts.containsKey(ID)) {
			try {
				contacts.get(ID).setFirstName(newName);
			} catch (IllegalArgumentException i) {
				i.printStackTrace();
			}
		}
	}
	
	// Updates last name
	public void updateLastName(String ID, String newName) {
		if (contacts.containsKey(ID)) {
			try {
				contacts.get(ID).setLastName(newName);
			} catch (IllegalArgumentException i) {
				i.printStackTrace();
			}
		}
	}
	
	//Updates phone number
	public void updatePhone(String ID, String newPhone) {
		if (contacts.containsKey(ID)) {
			try {
				contacts.get(ID).setPhone(newPhone);
			} catch (IllegalArgumentException i) {
				i.printStackTrace();
			}
		}
	}
	
	//Updates address
	public void updateAddress(String ID, String newAddress) {
		if (contacts.containsKey(ID)) {
			try {
				contacts.get(ID).setAddress(newAddress);
			} catch (IllegalArgumentException i) {
				i.printStackTrace();
			}
		}
	}

}