public class Task {
	private final String TaskID;
	private String Name;
	private String Description;
	
	//Validates a contact ID
	private final boolean validID(String ID) {
		if (!(ID.isEmpty()) && ID.length() <= 10) {
			return true;
		}
		return false;
	}
	
	//Validates a contact name
	private final boolean validName(String name) {
		if (!(name.isEmpty()) && name.length() <= 20) {
			return true;
		}
		return false;
	}
	
	//Validates a Description
	private final boolean validDescription(String TheDescription) {
		if (!(TheDescription.isEmpty()) && TheDescription.length() <= 50) {
			return true;
		}
		return false;
	}
/**
 * Contact constructor
 * @param ID,first,last,phoneNumber,TheDescription
 * @throws IllegalArgumentException
 */
public Task(String ID, 
		String name,
		String TheDescription) throws IllegalArgumentException {
	
	// print error if ID is longer than 10, otherwise assign ID to TaskID
	if (this.validID(ID)) {
		this.TaskID = ID;
	} else {
		throw new IllegalArgumentException("ERROR: Invalid Input ID, print error if ID is longer than 10 characters");
	}
	
	// print error if first is longer than 20 or null; otherwise assign first to firstName
	if (this.validName(name)) {
		this.Name = name;
	} else {
		throw new IllegalArgumentException("ERROR: Invalid Input name, print error if first is longer than 10 characters");
	}
	
	// print error is TheDescription is longer than 50 or null; otherwise assign to address
	if (this.validDescription(TheDescription)) {
		this.Description = TheDescription;
	} else {
		throw new IllegalArgumentException("ERROR: Invalid Input address, print error is TheDescription is longer than 30 characters");
	}}

//***Setters and Getters***

/**
 * ID get method
 * @return String ID
 */
public String getID() {
	return this.TaskID;
}

/**
 * First name get method
 * @return String firstName
 */
public String getName() {
	return this.Name;
}

/**
 * Description get method
 * @return String address
 */
public String getDescription() {
	return this.Description;
}

//  name setting method
public void setName(String name) throws IllegalArgumentException {
	if (this.validName(name)) {
		this.Name = name;
	} else {
		throw new IllegalArgumentException("ERROR: Invalid Input must be equal to or under 10 characters");
	}
}


//Description setting method
public void setDescription(String TheDescription) throws IllegalArgumentException {
	if (this.validDescription(TheDescription)) {
		this.Description = TheDescription;
	} else {
		throw new IllegalArgumentException("ERROR: Invalid Input address must be equal to or under 30 characters");
	}
}}

	