public class Contact {
	private final String contactID;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	//Validates a contact ID
	private final boolean validID(String ID) {
		if (!(ID.isEmpty()) && ID.length() <= 10) {
			return true;
		}
		return false;
	}
	
	//Validates a contact name
	private final boolean validName(String name) {
		if (!(name.isEmpty()) && name.length() <= 10) {
			return true;
		}
		return false;
	}
	
	// Validates a phone number
	private final boolean validPhone(String phoneNumber) {
		if (!(phoneNumber.isEmpty()) && phoneNumber.length() == 10) {
			return true;
		}
		return false;
	}
	
	//Validates an address
	private final boolean validAddress(String theAddress) {
		if (!(theAddress.isEmpty()) && theAddress.length() <= 30) {
			return true;
		}
		return false;
	}
	
	/**
	 * Contact constructor
	 * @param ID,first,last,phoneNumber,theAddress
	 * @throws IllegalArgumentException
	 */
	public Contact(String ID, 
			String first, 
			String last, 
			String phoneNumber, 
			String theAddress) throws IllegalArgumentException {
		
		// print error if ID is longer than 10, otherwise assign ID to contactID
		if (this.validID(ID)) {
			this.contactID = ID;
		} else {
			throw new IllegalArgumentException("ERROR: Invalid Input ID, print error if ID is longer than 10 characters");
		}
		
		// print error if first is longer than 10 or null; otherwise assign first to firstName
		if (this.validName(first)) {
			this.firstName = first;
		} else {
			throw new IllegalArgumentException("ERROR: Invalid Input name, print error if first is longer than 10 characters");
		}
		
		// print error if last is longer than 10 or null; otherwise assign last to lastName
		if (this.validName(last)) {
			this.lastName = last;
		} else {
			throw new IllegalArgumentException("ERROR: Invalid Input name, print error if last is longer than 10 characters");
		}
		
		// print error if phoneNumber is too long, too short, or null; otherwise assign to phone
		if (this.validPhone(phoneNumber)) {
			this.phone = phoneNumber;
		} else {
			throw new IllegalArgumentException("ERROR: Invalid Input phone number, print error if phoneNumber is too long, too short, or null");
		}
		
		// print error is theAddress is longer than 30 or null; otherwise assign to address
		if (this.validAddress(theAddress)) {
			this.address = theAddress;
		} else {
			throw new IllegalArgumentException("ERROR: Invalid Input address, print error is theAddress is longer than 30 characters");
		}
	}
	
	
	//***Setters and Getters***
	
	/**
	 * ID get method
	 * @return String ID
	 */
	public String getID() {
		return this.contactID;
	}
	
	/**
	 * First name get method
	 * @return String firstName
	 */
	public String getFirstName() {
		return this.firstName;
	}
	
	/**
	 * Last name get method
	 * @return String lastName
	 */
	public String getLastName() {
		return this.lastName;
	}
	
	/**
	 * Phone number get method
	 * @return String phone
	 */
	public String getPhone() {
		return this.phone;
	}
	
	/**
	 * Address get method
	 * @return String address
	 */
	public String getAddress() {
		return this.address;
	}
	
	// First name setting method
	public void setFirstName(String first) throws IllegalArgumentException {
		if (this.validName(first)) {
			this.firstName = first;
		} else {
			throw new IllegalArgumentException("ERROR: Invalid Input must be equal to or under 10 characters");
		}
	}
	
	//Last name setting method
	public void setLastName(String last) throws IllegalArgumentException {
		if (this.validName(last)) {
			this.lastName = last;
		} else {
			throw new IllegalArgumentException("ERROR: Invalid Input must be equal to or under 10 characters");
		}
	}
	
	//Phone number setting method
	public void setPhone(String phoneNumber) throws IllegalArgumentException {
		if (this.validPhone(phoneNumber)) {
			this.phone = phoneNumber;
		} else {
			throw new IllegalArgumentException("ERROR: Invalid Input must be equal to 10 digits");
		}
	}
	
	//Address setting method
	public void setAddress(String theAddress) throws IllegalArgumentException {
		if (this.validAddress(theAddress)) {
			this.address = theAddress;
		} else {
			throw new IllegalArgumentException("ERROR: Invalid Input address must be equal to or under 30 characters");
		}
	}
	
}

