import java.util.HashMap;

public class TaskService {
	int currentID = 0;
	HashMap<String, Task> tasks = new HashMap<String, Task>(); //hash map to hold tasks
	
	//Adds a Task @param Name,Description
	public void addTask(String Name, String TheDescription) {
		++currentID;
		String newID = Integer.toString(currentID);
		
		try {
			Task newTask = new Task(newID, Name, TheDescription);
			tasks.put(newTask.getID(), newTask);
		} catch(IllegalArgumentException i) {
			i.printStackTrace();
		}
	}
	
	//Deletes a Task by ID
	public void deleteTask(String ID) {
		if (tasks.containsKey(ID)) {
			tasks.remove(ID);
		}
	}
	
	//Updates name
	public void updateName(String ID, String newName) {
		if (tasks.containsKey(ID)) {
			try {
				tasks.get(ID).setName(newName);
			} catch (IllegalArgumentException i) {
				i.printStackTrace();
			}
		}
	}
	
	//Updates Description
	public void updateDescription(String ID, String newDescription) {
		if (tasks.containsKey(ID)) {
			try {
				tasks.get(ID).setDescription(newDescription);
			} catch (IllegalArgumentException i) {
				i.printStackTrace();
			}
		}
	}

}