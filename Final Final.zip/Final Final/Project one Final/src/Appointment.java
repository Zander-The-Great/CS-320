import java.util.Date;

public class Appointment {

	 //Private Variables
	private String appointmentId;
	private Date date;
	private String description;
	
	//Constructor
	public Appointment (String AppointmentId, Date date, String Thedescription){
	 this.appointmentId = AppointmentId;
	 this.date = date;
	 this.description = Thedescription;
	}
	
	//Access for appointment Id
	public String getAppointmentId() {
	
	 return appointmentId;
	}
	
	//Mutator for appointment Id
	//Check if ID is less than 10 chars and not null
	public void setApptId(String appointmentId) {
		
	 if ((appointmentId.length() > 10 || appointmentId == null)) {
		 
	 throw new IllegalArgumentException("Invalid");
	 
	}
	 
	this.appointmentId = appointmentId;
	}
	
	 //Access for date
	public Date getDate() {
		
	 return date;
	 
	}
	
	//Check if date is not in past or null
	public void setDate (Date date) {
		
	//Create date and store
	Date currentDate = new Date();
	 if ((!currentDate.before(date))) {
		 
	 throw new IllegalArgumentException("Invalid");
	 
	 }
	 
	 this.date = date;
	 
	 }
	 //Access for description
	public String getDescription() {
		
	 return description;
	 
	}
	// set description
	//Check description < 50 chars || not null
	public void setDescription (String Thedescription){
		
	if ((Thedescription.length() > 50 || Thedescription == null)) {
		
	throw new IllegalArgumentException("Invalid");
	
	}
	
	this.description = Thedescription;
	
	}
	
	}
