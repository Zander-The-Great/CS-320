import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
	// Contacts have unique ID
	@Test
	@DisplayName("Contacts are added with unique ID")
	void UniqueIdTest() {
		ContactService contacts = new ContactService();
		contacts.addContact("Joe", "Dirt", "1234567890", "Test Descript");
		contacts.addContact("Jake", "Sheehan", "5555555555", "20 wilson");
		contacts.addContact("Allison", "Sheehan", "5555555551", "22 norway");
		assertNotEquals(contacts.contacts.get("1").getID(), contacts.contacts.get("2").getID());
		assertNotEquals(contacts.contacts.get("2").getID(), contacts.contacts.get("3").getID());
		assertNotEquals(contacts.contacts.get("1").getID(), contacts.contacts.get("3").getID());
	}
	
	// Contacts can be deleted
	@Test
	@DisplayName("Contacts can be deleted")
	void DeleteContactTest() {
		ContactService contacts = new ContactService();
		contacts.addContact("Joe", "Dirt", "1234567890", "Test Descript");
		contacts.addContact("Jake", "Sheehan", "5555555555", "20 wilson");
		contacts.addContact("Allison", "Sheehan", "5555555551", "22 norway");
		contacts.deleteContact("2");
		assertFalse(contacts.contacts.containsKey("2"));
	}
	
	// First name can be updated
	@Test
	@DisplayName("Fist name can be updated")
	void UpdateFirstNameTest() {
		ContactService contacts = new ContactService();
		contacts.addContact("Joe", "Dirt", "1234567890", "Test Descript");
		contacts.updateFirstName("1", "Bob");
		assertEquals("Bob", contacts.contacts.get("1").getFirstName());
	}
	
	// Last name can be updated
	@Test
	@DisplayName("Last name can be updated")
	void UpdateLastNameTest() {
		ContactService contacts = new ContactService();
		contacts.addContact("Joe", "Dirt", "1234567890", "Test Descript");
		contacts.updateLastName("1", "Doe");
		assertEquals("Doe", contacts.contacts.get("1").getLastName());
	}
	
	// Phone number can be updated
	@Test
	@DisplayName("Phone number can be updated")
	void UpdatePhoneTest() {
		ContactService contacts = new ContactService();
		contacts.addContact("Joe", "Dirt", "1234567890", "Test Descript");
		contacts.updatePhone("1", "5555555555");
		assertEquals("5555555555", contacts.contacts.get("1").getPhone());
	}
	
	// Address can be updated
	@Test
	@DisplayName("Address can be updated")
	void UpdateAddressTest() {
		ContactService contacts = new ContactService();
		contacts.addContact("Joe", "Dirt", "1234567890", "Test Descript");
		contacts.updateAddress("1", "22 wilson");
		assertEquals("22 wilson", contacts.contacts.get("1").getAddress());
	}
	
}