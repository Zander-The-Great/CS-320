import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class TaskTest {
	
	/**
	 * ID Requirements Test Suite
	 */
	
	// An ID with 1 char is valid
	@Test
	@DisplayName("Accepts ID with length of 1")
	void IdWithOneCharTest() throws IllegalArgumentException {
		Task task = new Task("1", "John","2 westerlow");
		assertEquals("1", task.getID());
	}
	
	// An ID with 10 char is valid
	@Test
	@DisplayName("Accepts ID with length of 10")
	void IdWithTenCharTest() throws IllegalArgumentException {
		Task task = new Task("1234567890", "John Smith", "2 westerlow");
		assertEquals("1234567890", task.getID());
	}
	
	// An ID longer than 10 chars throw exception
	@Test
	@DisplayName("ID more than 10 characters throws exception")
	void IdWithMoreThanTenCharsTest() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345678901", "John Smith", "2 westerlow");
		});
	}
	
	// A null ID throws an exception
	@Test
	@DisplayName("Null ID throws exception")
	void NullIDTest() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("", "John Smith", "2 westerlow");
		});
	}
	
	
	/**
	 * Name Requirements Test Suite
	 */
	
	// A  name with 1 char is valid
	@Test
	@DisplayName("Accepts name with length of 1")
	void FirstNameWithOneCharTest() throws IllegalArgumentException {
		Task task = new Task("1", "A", "2 west");
		assertEquals("A", task.getName());
	}
	
	// A  name with 10 char is valid
	@Test
	@DisplayName("Accepts first name with length of 10")
	void FirstNameWithTenCharTest() throws IllegalArgumentException {
		Task task = new Task("1", "ABCDEFGHIJ", "2 west");
		assertEquals("ABCDEFGHIJ", task.getName());
	}
	
	// A  name longer than 20 chars throw exception
	@Test
	@DisplayName("Name more than 20 characters throws exception")
	void NameWithMoreThanTenCharsTest() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("1", "ABCDEFGHIJKLMNOASKITW", "2 west");
		});
	}
	
	// A null name throws an exception
	@Test
	@DisplayName("Null name throws exception")
	void NullFirstNameTest() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("1", "", "2 west");
		});
	}
	
	
	/**
	 * Description Requirements Test Suite
	 */
	
	// An Description with 1 char is valid
	@Test
	@DisplayName("Accepts Description with length of 1")
	void AddressWithOneCharTest() throws IllegalArgumentException {
		Task task = new Task("1", "John", "5");
		assertEquals("5", task.getDescription());
	}
	
	// An Description with 30 char is valid
	@Test
	@DisplayName("Accepts Description with length of 30")
	void AddressWithThirtyCharTest() throws IllegalArgumentException {
		Task task = new Task("1", "John", "ABCDEFGHIJKLMNOPQRSTUVWXYZABCD");
		assertEquals("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD", task.getDescription());
	}
	
	// An Description longer than 50 chars throw exception
	@Test
	@DisplayName("Description more than 50 characters throws exception")
	void AddressWithMoreThanThirtyCharsTest() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("1", "John","ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFASDFGHJKLOPIUYTREWQ");
		});
	}
	
	// A null address throws an exception
	@Test
	@DisplayName("Null Description throws exception")
	void NullAddressTest() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1", "John", "Smith", "5555555555", "");
		});
	}
	
}