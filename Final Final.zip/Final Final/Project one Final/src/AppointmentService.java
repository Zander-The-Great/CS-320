import java.util.List;
import java.util.Date;
import java.util.ArrayList;


public class AppointmentService {
	
//Storage ArrayList for Appointments list
public static List <Appointment> AppointmentsList;

//Constructor for AppointmentService
public AppointmentService (String appointmentId, Date date, String Thedescription){
	
 AppointmentsList = new ArrayList<Appointment>();
 
 }

// *** adding an appointment Method ***
public static boolean newAppointment(String appointmentId, Date date, String
Thedescription) {
	
 for (Appointment appointment : AppointmentsList) {
	 
 if (appointment.getAppointmentId().equals(appointmentId))
 {
	 
 return false;
 
 }
 }
 
AppointmentsList.add(new Appointment(appointmentId, date, Thedescription));
 return true;
}

//*** deleting appointment Method***
public Appointment deleteAppt(String apptId){
	
for (int x = 0; x < AppointmentsList.size(); x++) {
	
if (AppointmentsList.get(x).getAppointmentId().equals(apptId)) {
	
 Appointment appointment = AppointmentsList.get(x);
AppointmentsList.remove(x);
 return appointment;
}
}
return null;
}


}
