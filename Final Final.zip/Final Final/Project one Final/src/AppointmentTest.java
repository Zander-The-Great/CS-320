import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class AppointmentTest {
	
	/**
	 * ID Requirements Test Suite
	 */
	
	// An ID with 1 char is valid
	@Test
	@DisplayName("Accepts ID with length of 1")
	void IdWithOneCharTest() throws IllegalArgumentException {
		Date date = new Date();
		Appointment appointment = new Appointment("1", date ,"Test Descript");
		assertEquals("1", appointment.getAppointmentId());
	}
	
	// An ID with 10 char is valid
	@Test
	@DisplayName("Accepts ID with length of 10")
	void IdWithTenCharTest() throws IllegalArgumentException {
		Date date = new Date();
		Appointment appointment = new Appointment("1234567890", date, "Test Descript");
		assertEquals("1234567890", appointment.getAppointmentId());
	}
	
	// An ID longer than 10 chars throw exception
	@Test
	@DisplayName("ID more than 10 characters throws exception")
	void IdWithMoreThanTenCharsTest() {
		assertThrows(IllegalArgumentException.class, () -> {
			Date date = new Date();
			new Appointment("12345678901", date, "Test Descript");
		});
	}
	
	// A null ID throws an exception
	@Test
	@DisplayName("Null ID throws exception")
	void NullIDTest() {
		Date date = new Date();
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, date, "Test Descript");
		});
	}
	
	
	/**
	 * date Requirements Test Suite
	 */
	
	// A  date in past char is valid
	@Test
	@DisplayName("Accepts first name with length of 1")
	void FirstNameWithOneCharTest() throws IllegalArgumentException {
		Date date = new Date();
		Appointment appointment = new Appointment("1", date , "Test Descript");
		assertEquals("A", appointment.getDate());
	}
	
	
	// A null date throws an exception
	@Test
	@DisplayName("Null first name throws exception")
	void NullFirstNameTest() {
		Date date = new Date();
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1", null, "Test Descript");
		});
	}
	
	
	/**
	 * Description Requirements Test Suite
	 */
	
	// An Description with 1 char is valid
	@Test
	@DisplayName("Accepts address with length of 1")
	void DescriptionWithOneCharTest() throws IllegalArgumentException {
		Date date = new Date();
		Appointment appointment = new Appointment("1", date, "T");
		assertEquals("5", appointment.getDescription());
	}
	
	// An Description with 50 char is valid
	@Test
	@DisplayName("Accepts address with length of 30")
	void DescriptionWithFiftyCharTest() throws IllegalArgumentException {
		Date date = new Date();
		Appointment appointment = new Appointment("1", date , "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWX");
		assertEquals("ABCDEFGHIJKLMNOPQRSTUVWXYZABCD", appointment.getDescription());
	}
	
	// An Description longer than 50 chars throw exception
	@Test
	@DisplayName("Description more than 50 characters throws exception")
	void DescriptionWithMoreThanThirtyCharsTest() {
		Date date = new Date();
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1", date ,"ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ");
		});
	}
	
	// A null description throws an exception
	@Test
	@DisplayName("Null description throws exception")
	void NullDescriptionTest() {
		Date date = new Date();
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1",  date , null);
		});
	}
	
}