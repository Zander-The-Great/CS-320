import static org.junit.Assert.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.Test;

public class AppointmentServiceTest {
@SuppressWarnings("deprecation")
Date date = new Date(2021, Calendar.AUGUST, 21);

//Testing for verification of appointment being added
 @Test
 public void newAppointmentTest() {
 AppointmentService appointmentService = new AppointmentService
("123456789", date, "Scheduled");
 assertEquals(true,AppointmentService.newAppointment("123456789",date,
"Scheduled"));
 }

 //Testing to delete appointment by ID
 @Test
 public void deleteApptTest() {
 AppointmentService appointmentService = new AppointmentService
("123456789", date, "Scheduled");
 Appointment a = appointmentService.deleteAppt("123456789");
 assertTrue(a == null);
 }

}
