import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
	// Contacts have unique ID
	@Test
	@DisplayName("Contacts are added with unique ID")
	void UniqueIdTest() {
		TaskService tasks = new TaskService();
		tasks.addTask("John", "2 west");
		tasks.addTask("Jake", "1 east");
		tasks.addTask("Allison", "3 south");
		assertNotEquals(tasks.tasks.get("1").getID(), tasks.tasks.get("2").getID());
		assertNotEquals(tasks.tasks.get("2").getID(), tasks.tasks.get("3").getID());
		assertNotEquals(tasks.tasks.get("1").getID(), tasks.tasks.get("3").getID());
	}
	
	// Contacts can be deleted
	@Test
	@DisplayName("Contacts can be deleted")
	void DeleteContactTest() {
		TaskService tasks = new TaskService();
		tasks.addTask("John", "1 west");
		tasks.addTask("Jake", "2 east");
		tasks.addTask("Allison",  "3 south");
		tasks.deleteTask("2");
		assertFalse(tasks.tasks.containsKey("2"));
	}
	
	// First name can be updated
	@Test
	@DisplayName("Fist name can be updated")
	void UpdateFirstNameTest() {
		TaskService tasks = new TaskService();
		tasks.addTask("John", "5 Main");
		tasks.updateName("1", "Bob");
		assertEquals("Bob", tasks.tasks.get("1").getName());
	}
	

	
	
	// description can be updated
	@Test
	@DisplayName("Address can be updated")
	void UpdateAddressTest() {
		TaskService tasks = new TaskService();
		tasks.addTask("John", "5 Main");
		tasks.updateDescription("1", "10 Washington");
		assertEquals("10 Washington", tasks.tasks.get("1").getDescription());
	}
	
}